PYTHAGORAS-LERNSTUDIO – GitHub Pages

1. Cria um repositório público chamado pythagoras no GitHub.
2. Envia index.html para a raiz do repositório.
3. Abre Settings > Pages.
4. Em Build and deployment escolhe Deploy from a branch.
5. Escolhe a branch main e a pasta /(root), depois Save.
6. O endereço será https://TEU-UTILIZADOR.github.io/pythagoras/
